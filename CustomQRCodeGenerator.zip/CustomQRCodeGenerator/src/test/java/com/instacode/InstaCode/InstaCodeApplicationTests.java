package com.instacode.InstaCode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstaCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
